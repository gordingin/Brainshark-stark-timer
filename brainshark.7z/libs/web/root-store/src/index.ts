export * from './lib/root-store.module';
export * from './lib/ngrx/app.state';
export * from './lib/ngrx/root.actions';
export * from './lib/ngrx/root.reducer';
export * from './lib/ngrx/root.selectors';
