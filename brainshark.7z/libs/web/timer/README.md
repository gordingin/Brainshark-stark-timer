# web-timer

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test web-timer` to execute the unit tests.
