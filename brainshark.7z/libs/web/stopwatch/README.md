# web-stopwatch

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test web-stopwatch` to execute the unit tests.
