export * from './lib/stopwatch.module';
