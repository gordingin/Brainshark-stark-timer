import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'brainshark-stopwatch',
  templateUrl: './stopwatch.component.html',
  styleUrls: ['./stopwatch.component.scss']
})
export class StopwatchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
