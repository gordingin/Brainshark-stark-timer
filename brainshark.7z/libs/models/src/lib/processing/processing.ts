export interface UIProcessing {
  show: boolean;
  
}


